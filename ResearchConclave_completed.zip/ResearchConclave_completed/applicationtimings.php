<?php

//user details
$username;
$designation;
$name;
$email;

//server details
$servername="localhost";
$serverusername="root";
$password="";
$database_name="research_conclave";
$error="";

//time details
$start="";
$end="";

session_start();
  $designation= $_SESSION["designation"];
  //check for empty
  if (empty($_SESSION["username"]) || ($designation!="Faculty_Convener") ) {
    header("location: home.php");
    exit;
  }
  $username=$_SESSION["username"];

  if (isset($_POST['home'])) {
    session_start();
    $_SESSION["username"]=$username;
    header("location:facultyc_home.php");
  }

  
  //database conncetion
  try{
    $conn= new PDO("mysql:host=$servername; dbname=$database_name", $serverusername);
    $conn-> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt= $conn->query("SELECT * FROM `users` WHERE `username`='$username';");
    $users=$stmt->fetchAll();
    foreach ($users as $result) {
      $name=$result[1];
      $email=$result[5];
      $user_id=$result[0];
    }

    //inital checking
    $stmt= $conn->query("SELECT * FROM `applicationtime`;");
    if ($stmt->rowCount()!=0) {
      $error="The dates are already given";
      $users=$stmt->fetchAll();
      foreach ($users as $result) {
         $start=$result["start"];
         $end=$result["end"];
       } 
    }

    if (isset($_POST['givedate'])) {
      $stmt= $conn->query("SELECT * FROM `applicationtime`;");
       $inputstart=$_POST["Start"];
        $inputend=$_POST["End"];
        //to calculate diff
        $date1=date_create($inputstart);
        $date2=date_create($inputend);
        $diff=date_diff($date1,$date2);

        $diff_no=$diff->format("%R%a");

        
      if ($stmt->rowCount()==0) {
       if (empty($inputstart)) {
            $error="Start Date Cannot be Empty";
          }  
        else if(empty($inputend)){
          $error="End Date cannot be empty";
        }
        elseif($diff_no<0){
          $error="End date Cannot be before start date";
        }
        else{
          $stmt= $conn->query("INSERT INTO `applicationtime` (`start`, `end`) VALUES ( '$inputstart', '$inputend');");
          $error="Uploaded Successfully";
          $start=$inputstart;
          $end=$inputend;    
        }

      }

      else{
        if (empty($inputstart)) {
             $error="Start Date Cannot be Empty";
           }  
         else if(empty($inputend)){
           $error="End Date cannot be empty";
         }

         elseif($diff_no<0){
           $error="End date Cannot be before start date";
         }
         else{
          $stmt= $conn->query("UPDATE `applicationtime` SET `start` = '$inputstart', `end` = '$inputend' WHERE `applicationtime`.`id` = 1;");
          $error="Successfully Changed";
          $start=$inputstart;
          $end=$inputend;
        }    
      }
       
    }

  } 
  catch(PDOException $e){
    $error=$e->getMessage() ;
    
  }




?>

<!DOCTYPE html>
<html>
<head>
  <title>Welcome bro</title>
  <style>
  table {
   width: 50%;
   color: #588c7e;
   font-family: monospace;
   font-size: 25px;
   text-align: left;
     } 
  th {
   background-color: #588c7e;
   color: white;
    padding: 20px;
    }
  tr:nth-child(even) {background-color: #f2f2f2}
  tr:nth-child(odd) {background-color: #ABB1A8}
  .button1{
    border: 0;
    background-color: none;
    display: block;
    margin-left: 90%;
    text-align: center
    font-size: 30px;
    border: 2px solid #2B7009;
    padding: 6px 8px;
    width: 140px;
    outline: none;
    color: black;
    border-radius: 12px;
    transition: 0.25s;
    cursor: pointer;
  }
 </style>
</head>
<body align="center" bgcolor="#ACEF84">
  <div style="background-color:#4CAD15">
    <br><h2>Give Start and End Date For Applications</h2><br>
  </div>
  
  <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"])?>" method="post">
      <input class="button1"type="submit" name="home" value="HOME">
  </form>
  <h3><?php echo $error; ?></h3><br>
  <div>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) ?>" method="post">
     Start Date:<input type="Date" name="Start"><br>
     End Date:<input type="Date" name="End"><br>

     <input type="submit" name="givedate" value="submit" > 

    </form><br><br><br>

    <h3> Start DATE: <?php echo $start; ?></h3>
     <h3> End DATE: <?php echo $end; ?></h3>
  </div>

</body>

</html>
