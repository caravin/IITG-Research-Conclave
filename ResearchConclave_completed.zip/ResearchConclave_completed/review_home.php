<?php
$username;
$designation;
$name;

$servername="localhost";
$serverusername="root";
$password="";
$database_name="research_conclave";
$error;
session_start();
	$designation= $_SESSION["designation"];
	//check for empty
	if (empty($_SESSION["username"]) || ($designation!="Reviewer(P)" && $designation!="Reviewer(O)")) {
		header("location: home.php");
		exit;
	}
	$username=$_SESSION["username"];
	
	//database conncetion
	try{
		$conn= new PDO("mysql:host=$servername; dbname=$database_name", $serverusername);
		$conn-> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

		$stmt= $conn->query("SELECT * FROM `users` WHERE `username`='$username';");
		$users=$stmt->fetchAll();
		foreach ($users as $result) {
			$name=$result[1];
		}
		if (isset($_POST['file'])) {
			session_start();
			$_SESSION["username"]=$username;
			header("location:reviewer_grad.php");
		}




	}	
	catch(PDOException $e){
		echo "Error: ".$e->getMessage() ;
	}

?>


<!DOCTYPE html>
<html>
<head>
	<title>Welcome bro</title>
	<title>Welcome bro</title>
	<script type="text/javascript" >
  			
  		function uploadfile(){
			window.location.replace("abstractupload.php");

		}
		function signout(){
			window.location.replace("signout.php");
		}
  	</script>
</head>
<style type="text/css">


	.navbar {
	  overflow: hidden;
	  background-color: rgb(0,200,0);
	  position: fixed; /* Set the navbar to fixed position */
	  top: 0;
	  align-content: center; /* Position the navbar at the top of the page */
	  width: 100%; /* Full width */
	}


	

	.text{
		width: 600px;
		padding left: 50%;
		display: inline-block;
	}

	.navbar input{
		  float: left;
		  display: block;
		  align-content: center;		 
		  text-align: center;
		  padding: 14px 16px;
		  text-decoration: none;
		  background-color:#ACEF84 ; 
		  margin-top: 15px;
	}

	.navbar button{
			margin-top: 15px;
		  float: left;
		  display: block;
		  background-color:#ACEF84 ; 
		  text-align: center;
		  padding: 14px 16px;
		  text-decoration: none;
	}

	.navbar h2{
		  float: left;
		  display: block;
			
		  text-align: center;
		  padding: 14px 16px;
		  text-decoration: none;
	}

	.button{
		border: 0;
		background-color: none;
		display: block;
		margin-left: 50%;
		text-align: center
		font-size: 30px;
		border: 2px solid #2B7009;
		padding: 6px 8px;
		width: 140px;
		outline: none;
		color: black;
		border-radius: 12px;
		transition: 0.25s;
		cursor: pointer;
	}
</style>
<body align="center" bgcolor="#ACEF84">
	<div class="navbar" >
		<br><h2>Hi!! <?php echo htmlspecialchars($_SESSION["username"]); ?> Lets Start</h2>
	
	<button  onclick="signout()">SIGNOUT</button>
	<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"])?>" method="post">
		<input  type="submit" name="file" value="GIVE SCORE">
	</form>
	</div>

	<br><br><br><br><br>
	
	<?php
		//to see the notices

		$stmt= $conn->query("SELECT * FROM `notices` ");
		$users=$stmt->fetchAll();
		foreach ($users as $result) {
			$pdf1=$result["file"];

			
	?>
	<div>
	<h2><?php echo $result["event"];?></h2>
	<h4 class="text"><?php echo $result["name"];?></h4>
	<br>
	<img src="data:image/jpeg;base64,<?php echo base64_encode($pdf1) ?>" style="height:400px;width:50%">
	<br><br>
	<h4 class="text" ><?php echo $result["description"];?></h4><br>
	</div>
	
	<?php
		}
	 ?>


</body>

</html>